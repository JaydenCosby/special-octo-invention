import com.example.owrx.core.*
import kotlin.math.*

var fails = 0
fun check(name: String, ok: Boolean, extra: String = "") {
    println((if (ok) "PASS " else "FAIL ") + name + (if (extra.isNotEmpty()) "  [$extra]" else ""))
    if (!ok) fails++
}

// reference IMA ADPCM encoder (standard algorithm) to roundtrip against our decoder
val IDX = intArrayOf(-1,-1,-1,-1,2,4,6,8,-1,-1,-1,-1,2,4,6,8)
val STEP = intArrayOf(7,8,9,10,11,12,13,14,16,17,19,21,23,25,28,31,34,37,41,45,50,55,60,66,73,80,88,97,107,118,130,143,157,173,190,209,230,253,279,307,337,371,408,449,494,544,598,658,724,796,876,963,1060,1166,1282,1411,1552,1707,1878,2066,2272,2499,2749,3024,3327,3660,4026,4428,4871,5358,5894,6484,7132,7845,8630,9493,10442,11487,12635,13899,15289,16818,18500,20350,22385,24623,27086,29794,32767)
class Ref { var si = 0; var p = 0; var step = 0
  fun d(n: Int): Int { si = (si + IDX[n]).coerceIn(0, 88)
    var diff = step shr 3; if (n and 1 != 0) diff += step shr 2; if (n and 2 != 0) diff += step shr 1; if (n and 4 != 0) diff += step; if (n and 8 != 0) diff = -diff
    p = (p + diff).coerceIn(-32768, 32767); step = STEP[si]; return p } }
class Enc { var pred = 0; var si = 0
  fun nib(s: Int): Int {
    val step = STEP[si]; var diff = s - pred; var n = 0
    if (diff < 0) { n = 8; diff = -diff }
    var tmp = step
    if (diff >= tmp) { n = n or 4; diff -= tmp }
    tmp = tmp shr 1; if (diff >= tmp) { n = n or 2; diff -= tmp }
    tmp = tmp shr 1; if (diff >= tmp) { n = n or 1 }
    // mirror decoder reconstruction (decoder uses current "step" state which lags one sample; match it)
    return n
  }
}

fun main() {
    // --- JSON ---
    val j = Json.parse("""{"type":"config","value":{"samp_rate":2400000,"center_freq":14150000,"fft_size":4096,"audio_compression":"adpcm","waterfall_levels":{"min":-88.5,"max":-20},"s":"a\"bé\n"},"arr":[1,2.5,true,null]}""").jMap()!!
    val cfg = ServerConfig().merge(j["value"].jMap()!!)
    check("json parse+config", cfg.sampRate == 2400000L && cfg.centerFreq == 14150000L && cfg.fftSize == 4096 && cfg.audioAdpcm && cfg.minLevel == -88.5f && cfg.ready)
    check("config range", cfg.lowFreq == 12950000L && cfg.highFreq == 15350000L)
    val out = Json.stringify(mapOf("a" to 1, "b" to listOf(1.5, "x\"y"), "c" to null))
    check("json stringify", out == """{"a":1,"b":[1.5,"x\"y"],"c":null}""", out)
    check("dsp msg", Protocol.dspParams(mapOf("offset_freq" to -5000L, "mod" to "usb", "low_cut" to 300)) ==
        """{"type":"dspcontrol","params":{"offset_freq":-5000,"mod":"usb","low_cut":300}}""")
    check("conn props", Protocol.connectionProperties(12000, 44100) ==
        """{"type":"connectionproperties","params":{"output_rate":12000,"hd_output_rate":44100}}""")

    // --- URLs ---
    val cases = mapOf(
        "sdr.example.org:8073" to "ws://sdr.example.org:8073/ws/",
        "http://sdr.example.org:8073/" to "ws://sdr.example.org:8073/ws/",
        "https://x.example/owrx" to "wss://x.example/owrx/ws/",
        "https://x.example/owrx/index.html?a=1#b" to "wss://x.example/owrx/ws/",
        "  HTTP://Foo.net  " to "ws://Foo.net/ws/")
    for ((i, e) in cases) check("wsUrl $i", Protocol.wsUrl(i).equals(e, true), Protocol.wsUrl(i))
    check("normalize", Protocol.normalizeUrl("http://A.b:8073/") == Protocol.normalizeUrl("a.b:8073"))

    // --- ADPCM: hand-built stream decodes deterministically; compare vs independent decoder ---
    val rnd = java.util.Random(1)
    val nibs = IntArray(4000)
    for (k in nibs.indices) nibs[k] = rnd.nextInt(16)
    val bytes = ByteArray(nibs.size / 2) { ((nibs[it*2] and 15) or ((nibs[it*2+1] and 15) shl 4)).toByte() }
    val ref = Ref(); val expect = IntArray(nibs.size) { ref.d(nibs[it]) }
    val got = ImaAdpcm().decode(bytes)
    check("adpcm == reference port", got.size == expect.size && got.indices.all { got[it].toInt() == expect[it] })

    // sync stream: SYNC + stepIndex(le16) + predictor(le16) then data; decoder must resume mid-stream
    val syn = java.io.ByteArrayOutputStream()
    syn.write("SYNC".toByteArray()); syn.write(byteArrayOf(10, 0, 0x34, 0x12)); syn.write(bytes, 0, 200)
    val dec = ImaAdpcm(); val o = dec.decodeWithSync(syn.toByteArray())
    check("sync stream length", o.size == 400, "${o.size}")
    val r2 = Ref(); r2.si = 10; r2.p = 0x1234; r2.step = 0
    check("sync stream values", (0 until 400).all { o[it].toInt() == r2.d(nibs[it]) })
    // sync marker split across two websocket frames must still be found
    val full = syn.toByteArray(); val d2 = ImaAdpcm()
    val a = d2.decodeWithSync(full.copyOfRange(0, 2)); val b = d2.decodeWithSync(full.copyOfRange(2, full.size))
    check("sync across frames", a.isEmpty() && b.size == 400)

    // --- FFT ---
    val raw = java.nio.ByteBuffer.allocate(1 + 16).order(java.nio.ByteOrder.LITTLE_ENDIAN)
    raw.put(1); for (v in floatArrayOf(-80f, -70.5f, -60f, -50f)) raw.putFloat(v)
    val f = Protocol.decodeFft(raw.array(), 1, false, ImaAdpcm())
    check("fft float32", f.size == 4 && f[1] == -70.5f)
    // adpcm fft: 10 pad samples then dB*100
    val vals = IntArray(10) { 0 } + IntArray(32) { -it * 40 }
    var p2 = 0; var s2 = 0; val nn = IntArray(vals.size)
    // encode with a tracking encoder identical to decoder semantic
    class Tr { var si=0; var p=0; var step=0
      fun enc(x: Int): Int { val st = if (step==0) 7 else step; var diff = x - p; var n = 0; if (diff<0){n=8;diff=-diff}
        // brute force best nibble using the exact decoder
        var best=0; var bestErr=Int.MAX_VALUE
        for (c in 0..15) { var ssi=(si+IDX[c]).coerceIn(0,88); var dd=step shr 3; if(c and 1!=0)dd+=step shr 2; if(c and 2!=0)dd+=step shr 1; if(c and 4!=0)dd+=step; if(c and 8!=0)dd=-dd
          val pp=(p+dd).coerceIn(-32768,32767); val e=abs(pp-x); if(e<bestErr){bestErr=e;best=c} }
        si=(si+IDX[best]).coerceIn(0,88); var dd=step shr 3; if(best and 1!=0)dd+=step shr 2; if(best and 2!=0)dd+=step shr 1; if(best and 4!=0)dd+=step; if(best and 8!=0)dd=-dd
        p=(p+dd).coerceIn(-32768,32767); step=STEP[si]; return best } }
    val tr = Tr(); for (k in vals.indices) nn[k] = tr.enc(vals[k])
    val fb = ByteArray(1 + nn.size / 2); fb[0] = 1
    for (k in 0 until nn.size / 2) fb[1 + k] = ((nn[2*k] and 15) or ((nn[2*k+1] and 15) shl 4)).toByte()
    val fd = Protocol.decodeFft(fb, 1, true, ImaAdpcm())
    check("fft adpcm size (pad dropped)", fd.size == 32, "${fd.size}")
    // quantisation of ADPCM on a slow ramp: allow a few dB error after the filter settles
    val errs = (8 until 32).map { abs(fd[it] - vals[it + 10] / 100f) }
    check("fft adpcm tracks ramp", errs.max() < 3f, "max err ${"%.2f".format(errs.max())} dB")

    // --- PCM raw ---
    val pb = java.nio.ByteBuffer.allocate(1 + 6).order(java.nio.ByteOrder.LITTLE_ENDIAN); pb.put(2); pb.putShort(100); pb.putShort(-200); pb.putShort(300)
    val ap = Protocol.decodeAudio(pb.array(), 1, false, ImaAdpcm())
    check("pcm16 audio", ap.toList() == listOf<Short>(100, -200, 300))

    // --- modes ---
    val usb = Modes.defaults.first { it.id == "usb" }.withWidth(2400)
    check("usb width", usb.low == 300 && usb.high == 2700, "${usb.low}..${usb.high}")
    val lsb = Modes.defaults.first { it.id == "lsb" }.withWidth(2400)
    check("lsb width", lsb.low == -2700 && lsb.high == -300 && lsb.width == 2400, "${lsb.low}..${lsb.high}")
    val am = Modes.defaults.first { it.id == "am" }.withWidth(9000)
    check("am centred", am.low == -4500 && am.high == 4500)
    val sm = Modes.fromServer(Json.parse("""[{"modulation":"usb","name":"USB","type":"analog","bandpass":{"low_cut":300,"high_cut":2700}},{"modulation":"ft8","name":"FT8","type":"digital","underlying":["usb"]}]"""))
    check("server modes keep analog only", sm.size == 1 && sm[0].high == 2700)

    // --- ReceiverBook parsing (nested station->receivers shape; also flat + html-embedded) ---
    val nested = """[{"label":"Test Station","location":{"type":"Point","coordinates":[8.5,47.4]},"receivers":[
        {"type":"openwebrx","version":"1.2.3","url":"http://a.example:8073"},
        {"type":"kiwisdr","url":"http://k.example:8073"},
        {"type":"OpenWebRX+","url":"https://b.example/sdr/"}]}]"""
    val r = ReceiverBook.parse(nested)
    check("receiverbook nested", r.size == 2 && r[0].lat == 47.4 && r[0].lon == 8.5 && r[1].url == "https://b.example/sdr/" && r[0].name == "Test Station", r.toString())
    val html = "<html><script>var receivers = $nested;\nvar x=1;</script></html>"
    check("receiverbook html-embedded", ReceiverBook.parse(html).size == 2)
    check("receiverbook garbage", ReceiverBook.parse("<html>nothing</html>").isEmpty())
    val dup = ReceiverBook.parse("""[{"label":"A","receivers":[{"type":"openwebrx","url":"http://x.y:1/"}]},{"label":"B","receivers":[{"type":"openwebrx","url":"x.y:1"}]}]""")
    check("receiverbook dedupe", dup.size == 1)

    println(if (fails == 0) "\nALL PASSED" else "\n$fails FAILED")
    System.exit(if (fails == 0) 0 else 1)
}
