#!/usr/bin/env bash
# Compiles the Android-independent protocol code with a plain Kotlin compiler and runs tools/CoreTest.kt.
# Needs `kotlinc` on PATH (no Android SDK required).
set -e
cd "$(dirname "$0")/.."
SRC=app/src/main/java/com/example/owrx/core
OUT=$(mktemp -d)
kotlinc $SRC/Json.kt $SRC/ImaAdpcm.kt $SRC/Protocol.kt $SRC/Modes.kt $SRC/ReceiverBook.kt tools/CoreTest.kt -include-runtime -d "$OUT/t.jar"
java -cp "$OUT/t.jar" CoreTestKt
