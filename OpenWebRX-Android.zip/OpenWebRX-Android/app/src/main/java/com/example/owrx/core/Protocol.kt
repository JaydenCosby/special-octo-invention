package com.example.owrx.core

import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Receiver geometry/stream settings, built up from the server's "config" messages. */
data class ServerConfig(
    val centerFreq: Long = 0,
    val sampRate: Long = 0,
    val fftSize: Int = 0,
    val audioAdpcm: Boolean = false,
    val fftAdpcm: Boolean = false,
    val startMod: String? = null,
    val startOffset: Long = 0,
    val squelch: Int = -150,
    val minLevel: Float = -88f,
    val maxLevel: Float = -20f,
    val maxClients: Int = 0,
    val sdrId: String? = null,
    val profileId: String? = null,
) {
    val ready: Boolean get() = sampRate > 0 && fftSize > 0
    val lowFreq: Long get() = centerFreq - sampRate / 2
    val highFreq: Long get() = centerFreq + sampRate / 2

    /** Same shape as the ids in the server's "profiles" list: "sdr|profile". */
    val profileKey: String? get() = if (sdrId != null && profileId != null) "$sdrId|$profileId" else null

    fun merge(m: Map<String, Any?>): ServerConfig {
        var c = this
        m["center_freq"].jNum()?.let { c = c.copy(centerFreq = it.toLong()) }
        m["samp_rate"].jNum()?.let { c = c.copy(sampRate = it.toLong()) }
        m["fft_size"].jNum()?.let { c = c.copy(fftSize = it.toInt()) }
        m["audio_compression"].jStr()?.let { c = c.copy(audioAdpcm = it == "adpcm") }
        m["fft_compression"].jStr()?.let { c = c.copy(fftAdpcm = it == "adpcm") }
        m["start_mod"].jStr()?.let { c = c.copy(startMod = it) }
        m["start_offset_freq"].jNum()?.let { c = c.copy(startOffset = it.toLong()) }
        m["initial_squelch_level"].jNum()?.let { c = c.copy(squelch = it.toInt()) }
        m["max_clients"].jNum()?.let { c = c.copy(maxClients = it.toInt()) }
        m["sdr_id"].jStr()?.let { c = c.copy(sdrId = it) }
        m["profile_id"].jStr()?.let { c = c.copy(profileId = it) }
        m["waterfall_levels"].jMap()?.let { lv ->
            lv["min"].jNum()?.let { c = c.copy(minLevel = it.toFloat()) }
            lv["max"].jNum()?.let { c = c.copy(maxLevel = it.toFloat()) }
        }
        return c
    }
}

data class Profile(val id: String, val name: String)

data class Bookmark(val name: String, val frequency: Long, val modulation: String?)

object Protocol {
    const val HANDSHAKE = "SERVER DE CLIENT client=owrx-android type=receiver"

    /** Output sample rates we ask the server to resample audio to. */
    const val AUDIO_RATE = 12000
    const val HD_AUDIO_RATE = 44100

    /** Frame types of binary websocket messages (first byte). */
    const val FRAME_FFT = 1
    const val FRAME_AUDIO = 2
    const val FRAME_SECONDARY_FFT = 3
    const val FRAME_HD_AUDIO = 4

    /** FFT frames in ADPCM mode start with 10 padding samples that must be dropped. */
    const val COMPRESS_FFT_PAD_N = 10

    /**
     * Turns the address of a receiver (as listed on ReceiverBook, or typed by the user)
     * into its websocket endpoint: http -> ws, https -> wss, path + "ws/".
     */
    fun wsUrl(input: String): String {
        var u = input.trim()
        if (!Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://").containsMatchIn(u)) u = "http://$u"
        u = u.substringBefore('#').substringBefore('?')
        val schemeEnd = u.indexOf("://") + 3
        val slash = u.indexOf('/', schemeEnd)
        var base = if (slash < 0) "$u/" else u
        // drop a trailing file name such as index.html
        val lastSlash = base.lastIndexOf('/')
        if (lastSlash >= schemeEnd && base.substring(lastSlash + 1).contains('.')) {
            base = base.substring(0, lastSlash + 1)
        }
        if (!base.endsWith("/")) base += "/"
        val ws = when {
            base.startsWith("https://", true) -> "wss://" + base.substring(8)
            base.startsWith("http://", true) -> "ws://" + base.substring(7)
            else -> base
        }
        return ws + "ws/"
    }

    /** Key used to recognise the same receiver regardless of scheme/trailing slash. */
    fun normalizeUrl(input: String): String {
        var u = input.trim()
        if (!Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://").containsMatchIn(u)) u = "http://$u"
        u = u.substringBefore('#').substringBefore('?')
        return u.trimEnd('/').lowercase()
    }

    fun connectionProperties(outputRate: Int, hdOutputRate: Int): String = Json.stringify(
        mapOf(
            "type" to "connectionproperties",
            "params" to mapOf("output_rate" to outputRate, "hd_output_rate" to hdOutputRate)
        )
    )

    fun dspParams(params: Map<String, Any?>): String =
        Json.stringify(mapOf("type" to "dspcontrol", "params" to params))

    fun dspStart(): String = Json.stringify(mapOf("type" to "dspcontrol", "action" to "start"))

    fun selectProfile(id: String): String =
        Json.stringify(mapOf("type" to "selectprofile", "params" to mapOf("profile" to id)))

    /** FFT frame -> dB values, low frequency first. [offset] skips the frame-type byte. */
    fun decodeFft(buf: ByteArray, offset: Int, adpcm: Boolean, codec: ImaAdpcm): FloatArray {
        if (!adpcm) {
            val n = (buf.size - offset) / 4
            val out = FloatArray(n)
            ByteBuffer.wrap(buf, offset, n * 4).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer().get(out)
            return out
        }
        codec.reset()
        val pcm = codec.decode(buf, offset, buf.size - offset)
        val n = pcm.size - COMPRESS_FFT_PAD_N
        if (n <= 0) return FloatArray(0)
        return FloatArray(n) { pcm[it + COMPRESS_FFT_PAD_N] / 100f }
    }

    /** Audio frame -> 16 bit mono PCM. */
    fun decodeAudio(buf: ByteArray, offset: Int, adpcm: Boolean, codec: ImaAdpcm): ShortArray {
        if (adpcm) return codec.decodeWithSync(buf, offset, buf.size - offset)
        val n = (buf.size - offset) / 2
        val out = ShortArray(n)
        ByteBuffer.wrap(buf, offset, n * 2).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(out)
        return out
    }
}
