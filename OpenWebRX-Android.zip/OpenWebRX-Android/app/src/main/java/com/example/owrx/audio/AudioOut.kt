package com.example.owrx.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.example.owrx.core.Protocol
import kotlin.math.max

/**
 * Streams the server's PCM to the speaker. Writes happen on a dedicated thread so the
 * websocket reader is never blocked by AudioTrack. The queue is bounded: if the network
 * delivers faster than real time the oldest audio is dropped to keep latency low.
 */
class AudioOut {
    private var track: AudioTrack? = null
    private var rate = 0
    private var pendingRate = 0
    private var thread: Thread? = null

    private val lock = Object()
    private val queue = ArrayDeque<ShortArray>()
    private var queuedSamples = 0
    @Volatile private var running = false
    @Volatile var volume: Float = 1f
        set(v) { field = v.coerceIn(0f, 1f); track?.setVolume(field) }
    @Volatile var muted: Boolean = false

    /** Which of the two server streams we play; HD (44.1 kHz) is used when the server offers it. */
    @Volatile var hdActive = false

    fun start() {
        if (running) return
        running = true
        thread = Thread({ loop() }, "owrx-audio").also { it.isDaemon = true; it.start() }
    }

    fun stop() {
        running = false
        synchronized(lock) { queue.clear(); queuedSamples = 0; lock.notifyAll() }
        thread?.join(500)
        thread = null
        release()
    }

    fun push(pcm: ShortArray, hd: Boolean) {
        if (!running || pcm.isEmpty()) return
        // when HD frames arrive, ignore the narrow stream (and vice versa)
        if (hd) hdActive = true
        else if (hdActive) return
        val r = if (hd) Protocol.HD_AUDIO_RATE else Protocol.AUDIO_RATE
        synchronized(lock) {
            if (r != pendingRate) {
                queue.clear(); queuedSamples = 0
                pendingRate = r
            }
            queue.addLast(pcm)
            queuedSamples += pcm.size
            // cap latency at ~1.2 s
            val cap = (pendingRate.takeIf { it > 0 } ?: r) * 12 / 10
            while (queuedSamples > cap && queue.size > 1) {
                queuedSamples -= queue.removeFirst().size
            }
            lock.notifyAll()
        }
    }

    fun clear() {
        synchronized(lock) { queue.clear(); queuedSamples = 0 }
        hdActive = false
    }

    private fun loop() {
        while (running) {
            val chunk: ShortArray
            val wantRate: Int
            synchronized(lock) {
                while (running && queue.isEmpty()) lock.wait(200)
                if (!running) return
                chunk = queue.removeFirst()
                queuedSamples -= chunk.size
                wantRate = pendingRate
            }
            if (wantRate != rate && wantRate > 0) openTrack(wantRate)
            val t = track ?: continue
            if (muted) {
                // keep timing but play silence
                val silent = ShortArray(chunk.size)
                t.write(silent, 0, silent.size)
            } else {
                t.write(chunk, 0, chunk.size)
            }
        }
    }

    private fun openTrack(sampleRate: Int) {
        release()
        val min = AudioTrack.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(max(min, sampleRate / 2 * 2))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        t.setVolume(volume)
        t.play()
        track = t
        rate = sampleRate
    }

    private fun release() {
        try { track?.stop() } catch (_: Exception) {}
        track?.release()
        track = null
        rate = 0
    }
}
