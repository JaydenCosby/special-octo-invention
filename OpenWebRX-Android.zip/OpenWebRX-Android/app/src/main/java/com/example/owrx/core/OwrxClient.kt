package com.example.owrx.core

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.util.concurrent.TimeUnit

/** Everything the UI needs to know about the live connection. */
interface ClientListener {
    fun onState(state: ConnState, message: String?)
    fun onConfig(cfg: ServerConfig)
    fun onFft(db: FloatArray)
    fun onAudio(pcm: ShortArray, hd: Boolean)
    fun onSmeter(db: Float)
    fun onProfiles(list: List<Profile>, currentKey: String?)
    fun onModes(modes: List<Mode>)
    fun onBookmarks(list: List<Bookmark>)
    fun onDetails(name: String?, location: String?)
    fun onClients(count: Int)
}

enum class ConnState { IDLE, CONNECTING, LIVE, BUSY, ERROR }

/**
 * Native OpenWebRX websocket client. All callbacks arrive on OkHttp's reader thread,
 * so listeners must hand work over to their own thread if they touch UI state.
 */
class OwrxClient(private val listener: ClientListener) {

    private val http = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .connectTimeout(12, TimeUnit.SECONDS)
        .build()

    private var socket: WebSocket? = null
    private var generation = 0

    @Volatile private var cfg = ServerConfig()
    private val fftCodec = ImaAdpcm()
    private val audioCodec = ImaAdpcm()
    private val hdCodec = ImaAdpcm()

    // last dsp parameters sent, so we only transmit changes (like the web client does)
    private val sent = HashMap<String, Any?>()
    @Volatile private var started = false

    fun connect(address: String) {
        disconnect()
        val gen = ++generation
        cfg = ServerConfig()
        sent.clear()
        started = false
        fftCodec.reset(); audioCodec.reset(); hdCodec.reset()
        listener.onState(ConnState.CONNECTING, null)

        val url = try {
            Protocol.wsUrl(address)
        } catch (e: Exception) {
            listener.onState(ConnState.ERROR, "Bad address")
            return
        }
        val req = try {
            Request.Builder().url(url.replaceFirst("ws", "http")).build()
        } catch (e: Exception) {
            listener.onState(ConnState.ERROR, "Bad address")
            return
        }

        socket = http.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                if (gen != generation) return
                webSocket.send(Protocol.HANDSHAKE)
                webSocket.send(Protocol.connectionProperties(Protocol.AUDIO_RATE, Protocol.HD_AUDIO_RATE))
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (gen != generation) return
                handleText(webSocket, text)
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                if (gen != generation) return
                handleBinary(bytes.toByteArray())
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (gen != generation) return
                listener.onState(ConnState.IDLE, "Disconnected")
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (gen != generation) return
                val why = when {
                    response != null -> "Server answered ${response.code}"
                    t.message != null -> t.message
                    else -> "Connection failed"
                }
                listener.onState(ConnState.ERROR, why)
            }
        })
    }

    fun disconnect() {
        generation++
        socket?.close(1000, null)
        socket = null
        started = false
    }

    // ---- outgoing ---------------------------------------------------------------------------

    /** Sends only the parameters that changed since the last call. */
    fun setDsp(params: Map<String, Any?>) {
        val ws = socket ?: return
        val diff = LinkedHashMap<String, Any?>()
        for ((k, v) in params) {
            if (!sent.containsKey(k) || sent[k] != v) diff[k] = v
        }
        if (diff.isEmpty() && started) return
        if (diff.isNotEmpty()) {
            ws.send(Protocol.dspParams(diff))
            sent.putAll(diff)
        }
        if (!started) {
            ws.send(Protocol.dspStart())
            started = true
        }
    }

    fun selectProfile(id: String) {
        socket?.send(Protocol.selectProfile(id))
    }

    // ---- incoming ---------------------------------------------------------------------------

    private fun handleText(ws: WebSocket, text: String) {
        if (text.startsWith("CLIENT DE SERVER")) return
        val root = try { Json.parse(text).jMap() } catch (_: Exception) { null } ?: return
        val value = root["value"]
        when (root["type"].jStr()) {
            "config" -> {
                val m = value.jMap() ?: return
                val before = cfg
                cfg = cfg.merge(m)
                // a profile switch resets the server side demodulator, so we must restart it
                if (before.profileKey != cfg.profileKey || before.centerFreq != cfg.centerFreq) {
                    sent.clear()
                    started = false
                }
                if (cfg.ready) {
                    listener.onConfig(cfg)
                    listener.onState(ConnState.LIVE, null)
                }
            }
            "smeter" -> value.jNum()?.let {
                if (it > 0) listener.onSmeter((10.0 * Math.log10(it)).toFloat())
            }
            "clients" -> value.jNum()?.let { listener.onClients(it.toInt()) }
            "profiles" -> {
                val list = value.jList()?.mapNotNull {
                    val m = it.jMap() ?: return@mapNotNull null
                    val id = m["id"].jStr() ?: return@mapNotNull null
                    Profile(id, m["name"].jStr() ?: id)
                } ?: return
                listener.onProfiles(list, cfg.profileKey)
            }
            "modes" -> {
                val modes = Modes.fromServer(value)
                if (modes.isNotEmpty()) listener.onModes(modes)
            }
            "bookmarks", "dial_frequencies" -> {
                val list = value.jList()?.mapNotNull {
                    val m = it.jMap() ?: return@mapNotNull null
                    val f = m["frequency"].jNum()?.toLong() ?: return@mapNotNull null
                    Bookmark(m["name"].jStr() ?: "", f, m["modulation"].jStr())
                } ?: return
                listener.onBookmarks(list)
            }
            "receiver_details" -> {
                val m = value.jMap() ?: return
                val loc = m["receiver_location"].jStr()
                    ?: m["receiver_location"].jMap()?.get("locator").jStr()
                listener.onDetails(m["receiver_name"].jStr(), loc)
            }
            "backoff" -> {
                val reason = root["reason"].jStr() ?: "Server is busy"
                listener.onState(ConnState.BUSY, reason)
            }
            "sdr_error" -> listener.onState(ConnState.ERROR, value.jStr() ?: "Receiver reports an error")
            "demodulator_error", "log_message" -> { /* informational */ }
        }
    }

    private fun handleBinary(bytes: ByteArray) {
        if (bytes.isEmpty()) return
        when (bytes[0].toInt() and 0xFF) {
            Protocol.FRAME_FFT -> {
                if (!cfg.ready) return
                val db = Protocol.decodeFft(bytes, 1, cfg.fftAdpcm, fftCodec)
                if (db.isNotEmpty()) listener.onFft(db)
            }
            Protocol.FRAME_AUDIO ->
                listener.onAudio(Protocol.decodeAudio(bytes, 1, cfg.audioAdpcm, audioCodec), false)
            Protocol.FRAME_HD_AUDIO ->
                listener.onAudio(Protocol.decodeAudio(bytes, 1, cfg.audioAdpcm, hdCodec), true)
            // secondary FFT (digital decoders) is not used by this audio-only client
        }
    }
}
