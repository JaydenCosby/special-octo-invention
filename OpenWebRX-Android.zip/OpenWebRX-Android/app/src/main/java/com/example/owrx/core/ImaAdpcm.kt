package com.example.owrx.core

/**
 * IMA ADPCM decoder matching the one in OpenWebRX's browser client
 * (AudioEngine.js: ImaAdpcmCodec). Two flavours:
 *  - [decode]: plain nibble stream (used for FFT frames, reset before every frame)
 *  - [decodeWithSync]: audio stream with periodic "SYNC" + stepIndex/predictor resync blocks
 */
class ImaAdpcm {
    private var stepIndex = 0
    private var predictor = 0
    private var step = 0

    private var synchronized = 0
    private var phase = 0
    private var syncCounter = 0
    private val syncBuffer = IntArray(4)
    private var syncBufferIndex = 0

    init {
        reset()
    }

    fun reset() {
        stepIndex = 0
        predictor = 0
        step = 0
        synchronized = 0
        syncCounter = 0
        phase = 0
        syncBufferIndex = 0
    }

    fun decode(data: ByteArray, offset: Int = 0, length: Int = data.size - offset): ShortArray {
        val out = ShortArray(length * 2)
        for (i in 0 until length) {
            val b = data[offset + i].toInt() and 0xFF
            out[i * 2] = nibble(b and 0x0F).toShort()
            out[i * 2 + 1] = nibble((b shr 4) and 0x0F).toShort()
        }
        return out
    }

    fun decodeWithSync(data: ByteArray, offset: Int = 0, length: Int = data.size - offset): ShortArray {
        val out = ShortArray(length * 2)
        var oi = 0
        for (idx in 0 until length) {
            val b = data[offset + idx].toInt() and 0xFF
            when (phase) {
                0 -> {
                    // searching for the "SYNC" marker
                    if (b != SYNC[synchronized++].code) synchronized = 0
                    if (synchronized == 4) {
                        syncBufferIndex = 0
                        phase = 1
                    }
                }
                1 -> {
                    // 4 bytes of codec state: int16 stepIndex, int16 predictor (little endian)
                    syncBuffer[syncBufferIndex++] = b
                    if (syncBufferIndex == 4) {
                        stepIndex = ((syncBuffer[1] shl 8) or syncBuffer[0]).toShort().toInt()
                        predictor = ((syncBuffer[3] shl 8) or syncBuffer[2]).toShort().toInt()
                        syncCounter = 1000
                        phase = 2
                    }
                }
                else -> {
                    out[oi++] = nibble(b and 0x0F).toShort()
                    out[oi++] = nibble(b shr 4).toShort()
                    if (syncCounter-- == 0) {
                        synchronized = 0
                        phase = 0
                    }
                }
            }
        }
        return if (oi == out.size) out else out.copyOf(oi)
    }

    private fun nibble(n: Int): Int {
        stepIndex += INDEX_TABLE[n]
        if (stepIndex < 0) stepIndex = 0
        if (stepIndex > 88) stepIndex = 88

        var diff = step shr 3
        if (n and 1 != 0) diff += step shr 2
        if (n and 2 != 0) diff += step shr 1
        if (n and 4 != 0) diff += step
        if (n and 8 != 0) diff = -diff

        predictor += diff
        if (predictor < -32768) predictor = -32768
        if (predictor > 32767) predictor = 32767

        step = STEP_TABLE[stepIndex]
        return predictor
    }

    companion object {
        private const val SYNC = "SYNC"

        private val INDEX_TABLE = intArrayOf(-1, -1, -1, -1, 2, 4, 6, 8, -1, -1, -1, -1, 2, 4, 6, 8)

        private val STEP_TABLE = intArrayOf(
            7, 8, 9, 10, 11, 12, 13, 14, 16, 17,
            19, 21, 23, 25, 28, 31, 34, 37, 41, 45,
            50, 55, 60, 66, 73, 80, 88, 97, 107, 118,
            130, 143, 157, 173, 190, 209, 230, 253, 279, 307,
            337, 371, 408, 449, 494, 544, 598, 658, 724, 796,
            876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066,
            2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358,
            5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899,
            15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767
        )
    }
}
