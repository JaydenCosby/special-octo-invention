package com.example.owrx.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import com.example.owrx.core.ServerConfig
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToLong

/**
 * Spectrum + waterfall + frequency scale, drawn natively on a Canvas.
 *
 * Touch: one finger tunes (tap or drag), two fingers pinch-zoom and pan.
 */
class WaterfallView(context: Context) : View(context) {

    /** Called with the absolute frequency (Hz) the user touched. */
    var onTune: ((Long) -> Unit)? = null

    var tunedHz: Long = 0
        set(v) { field = v; invalidate() }
    var lowCut: Int = 0
        set(v) { field = v; invalidate() }
    var highCut: Int = 0
        set(v) { field = v; invalidate() }

    /** Touch positions snap to this grid (Hz). 0 = no snapping. */
    var snapHz: Int = 0

    private var cfg = ServerConfig()
    private var bmp: Bitmap? = null
    private var rowPixels = IntArray(0)
    private var head = 0
    private var rowsFilled = 0
    private var lastRow = FloatArray(0)

    private var spanHz = 1.0
    private var centerHz = 0.0

    private var minDb = -90f
    private var maxDb = -20f
    private var levelsPrimed = false

    private val density = resources.displayMetrics.density
    private val sp = resources.displayMetrics.scaledDensity

    private val palette = IntArray(256) { i -> heat(i / 255f) }

    private val paintBmp = Paint(Paint.FILTER_BITMAP_FLAG)
    private val paintBg = Paint().apply { color = Color.rgb(8, 12, 20) }
    private val paintScaleBg = Paint().apply { color = Color.rgb(20, 28, 42) }
    private val paintTick = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(200, 170, 190, 215); strokeWidth = density
    }
    private val paintText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(200, 215, 235); textSize = 11 * sp; textAlign = Paint.Align.CENTER
    }
    private val paintGrid = Paint().apply {
        color = Color.argb(40, 255, 255, 255); strokeWidth = 1f
    }
    private val paintLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(120, 220, 255); strokeWidth = 1.5f * density
        style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND
    }
    private val paintFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(60, 80, 180, 255); style = Paint.Style.FILL
    }
    private val paintBand = Paint().apply { color = Color.argb(70, 255, 200, 40) }
    private val paintCarrier = Paint().apply {
        color = Color.rgb(255, 80, 60); strokeWidth = 2f * density
    }
    private val path = Path()
    private val fillPath = Path()

    private var lastFocusX = 0f
    private val scaler = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScaleBegin(d: ScaleGestureDetector): Boolean {
            lastFocusX = d.focusX
            return true
        }

        override fun onScale(d: ScaleGestureDetector): Boolean {
            if (width == 0) return true
            val focusHz = freqAt(d.focusX)
            val dx = d.focusX - lastFocusX
            lastFocusX = d.focusX
            spanHz = (spanHz / d.scaleFactor).coerceIn(minSpan(), maxSpan())
            // keep the frequency under the fingers fixed, then follow the pan
            centerHz = focusHz - (d.focusX / width - 0.5) * spanHz - dx / width * spanHz
            clampView()
            invalidate()
            return true
        }
    })

    // ---- public API -------------------------------------------------------------------------

    fun setConfig(c: ServerConfig) {
        val geometryChanged = c.fftSize != cfg.fftSize || c.sampRate != cfg.sampRate ||
            c.centerFreq != cfg.centerFreq
        cfg = c
        if (!c.ready) return
        if (geometryChanged) {
            bmp?.recycle()
            bmp = Bitmap.createBitmap(c.fftSize, ROWS, Bitmap.Config.ARGB_8888)
            rowPixels = IntArray(c.fftSize)
            head = 0
            rowsFilled = 0
            lastRow = FloatArray(0)
            spanHz = c.sampRate.toDouble()
            centerHz = c.centerFreq.toDouble()
            minDb = c.minLevel
            maxDb = c.maxLevel
            levelsPrimed = false
        }
        invalidate()
    }

    fun addRow(db: FloatArray) {
        val b = bmp ?: return
        if (db.size != b.width) return
        lastRow = db
        updateLevels(db)

        head = (head - 1 + ROWS) % ROWS
        val range = max(maxDb - minDb, 1f)
        for (i in db.indices) {
            val t = ((db[i] - minDb) / range).coerceIn(0f, 1f)
            rowPixels[i] = palette[(t * 255).toInt()]
        }
        b.setPixels(rowPixels, 0, b.width, 0, head, b.width, 1)
        if (rowsFilled < ROWS) rowsFilled++
        invalidate()
    }

    fun zoomBy(factor: Double) {
        spanHz = (spanHz / factor).coerceIn(minSpan(), maxSpan())
        clampView()
        invalidate()
    }

    fun showAll() {
        spanHz = cfg.sampRate.toDouble().coerceAtLeast(1.0)
        centerHz = cfg.centerFreq.toDouble()
        invalidate()
    }

    /** Scrolls the view so the tuned frequency is visible (called after band jumps). */
    fun followTuned() {
        val lo = centerHz - spanHz / 2
        val hi = centerHz + spanHz / 2
        if (tunedHz < lo + spanHz * 0.08 || tunedHz > hi - spanHz * 0.08) {
            centerHz = tunedHz.toDouble()
            clampView()
            invalidate()
        }
    }

    fun spanHz(): Double = spanHz

    // ---- geometry ---------------------------------------------------------------------------

    private fun minSpan() = min(10_000.0, max(cfg.sampRate.toDouble(), 1.0))
    private fun maxSpan() = max(cfg.sampRate.toDouble(), 1.0)

    private fun clampView() {
        if (!cfg.ready) return
        val half = spanHz / 2
        val lo = cfg.lowFreq + half
        val hi = cfg.highFreq - half
        centerHz = if (lo >= hi) cfg.centerFreq.toDouble() else centerHz.coerceIn(lo, hi)
    }

    private fun freqAt(x: Float): Double = centerHz - spanHz / 2 + x / max(width, 1) * spanHz

    private fun xAt(f: Double): Float = ((f - (centerHz - spanHz / 2)) / spanHz * width).toFloat()

    private val specH get() = height * 0.24f
    private val scaleH get() = 22 * density

    private fun updateLevels(db: FloatArray) {
        // cheap percentile estimate over a 256-point sample
        val n = min(256, db.size)
        val s = FloatArray(n) { db[it * db.size / n] }
        s.sort()
        val lo = s[(n * 0.05f).toInt()] - 3f
        val hi = s[n - 1 - (n * 0.01f).toInt()] + 6f
        val targetMin = lo
        val targetMax = max(hi, lo + 25f)
        if (!levelsPrimed) {
            minDb = targetMin; maxDb = targetMax; levelsPrimed = true
        } else {
            minDb += (targetMin - minDb) * 0.03f
            maxDb += (targetMax - maxDb) * 0.03f
        }
    }

    // ---- drawing ----------------------------------------------------------------------------

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawRect(0f, 0f, w, h, paintBg)
        if (!cfg.ready) return

        val spec = specH
        val scale = scaleH
        drawSpectrum(c, w, spec)
        c.drawRect(0f, spec, w, spec + scale, paintScaleBg)
        drawScale(c, w, spec, scale)
        drawWaterfall(c, w, spec + scale, h)
        drawTuning(c, w, h, spec)
    }

    private fun drawSpectrum(c: Canvas, w: Float, bottom: Float) {
        val row = lastRow
        if (row.isEmpty()) return
        val n = row.size
        val range = max(maxDb - minDb, 1f)
        val lo = centerHz - spanHz / 2
        val b0 = ((lo - cfg.lowFreq) / cfg.sampRate * n).toInt().coerceIn(0, n - 1)
        val b1 = (((lo + spanHz) - cfg.lowFreq) / cfg.sampRate * n).toInt().coerceIn(b0 + 1, n)
        val visible = b1 - b0
        val step = max(1, visible / max(w.toInt(), 1))

        path.reset(); fillPath.reset()
        var first = true
        var i = b0
        while (i < b1) {
            // peak over the decimation window so narrow carriers stay visible
            var m = row[i]
            var k = 1
            while (k < step && i + k < b1) { if (row[i + k] > m) m = row[i + k]; k++ }
            val x = (i - b0).toFloat() / visible * w
            val y = bottom - ((m - minDb) / range).coerceIn(0f, 1f) * (bottom - 4 * density)
            if (first) { path.moveTo(x, y); fillPath.moveTo(x, bottom); fillPath.lineTo(x, y); first = false }
            else { path.lineTo(x, y); fillPath.lineTo(x, y) }
            i += step
        }
        fillPath.lineTo(w, bottom)
        fillPath.close()
        c.drawPath(fillPath, paintFill)
        c.drawPath(path, paintLine)
    }

    private fun drawScale(c: Canvas, w: Float, top: Float, hgt: Float) {
        val step = niceStep(spanHz / 6.0)
        val lo = centerHz - spanHz / 2
        var f = kotlin.math.ceil(lo / step) * step
        val hi = lo + spanHz
        val baseline = top + hgt
        while (f <= hi) {
            val x = xAt(f)
            c.drawLine(x, baseline - 6 * density, x, baseline, paintTick)
            c.drawText(formatTick(f, step), x, top + hgt - 8 * density, paintText)
            f += step
        }
    }

    private fun drawWaterfall(c: Canvas, w: Float, top: Float, bottom: Float) {
        val b = bmp ?: return
        if (rowsFilled == 0) return
        val lo = centerHz - spanHz / 2
        val sx0 = ((lo - cfg.lowFreq) / cfg.sampRate * b.width).toFloat()
        val sx1 = (((lo + spanHz) - cfg.lowFreq) / cfg.sampRate * b.width).toFloat()
        val left = sx0.toInt().coerceIn(0, b.width - 1)
        val right = sx1.toInt().coerceIn(left + 1, b.width)

        val availH = bottom - top
        // each row is ROW_PX tall on screen; newest at the top
        val rowPx = max(2f * density, availH / ROWS)
        val rowsOnScreen = min(rowsFilled, (availH / rowPx).toInt())
        val src = Rect()
        val dst = RectF()
        var drawn = 0
        var seg = head
        while (drawn < rowsOnScreen) {
            val run = min(rowsOnScreen - drawn, ROWS - seg)
            src.set(left, seg, right, seg + run)
            dst.set(0f, top + drawn * rowPx, w, top + (drawn + run) * rowPx)
            c.drawBitmap(b, src, dst, paintBmp)
            drawn += run
            seg = (seg + run) % ROWS
        }
    }

    private fun drawTuning(c: Canvas, w: Float, h: Float, specBottom: Float) {
        val x0 = xAt((tunedHz + lowCut).toDouble())
        val x1 = xAt((tunedHz + highCut).toDouble())
        val xc = xAt(tunedHz.toDouble())
        val left = min(x0, x1)
        val right = max(x0, x1)
        val minW = 3 * density
        c.drawRect(left, 0f, max(right, left + minW), h, paintBand)
        c.drawLine(xc, 0f, xc, h, paintCarrier)

        // faint vertical grid under the scale
        val step = niceStep(spanHz / 6.0)
        var f = kotlin.math.ceil((centerHz - spanHz / 2) / step) * step
        while (f <= centerHz + spanHz / 2) {
            val x = xAt(f)
            c.drawLine(x, specBottom + scaleH, x, h, paintGrid)
            f += step
        }
    }

    // ---- touch ------------------------------------------------------------------------------

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaler.onTouchEvent(e)
        if (scaler.isInProgress || e.pointerCount > 1) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> parent?.requestDisallowInterceptTouchEvent(true)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                parent?.requestDisallowInterceptTouchEvent(false)
        }
        if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
            if (!cfg.ready) return true
            var f = freqAt(e.x).roundToLong()
            if (snapHz > 0) f = (f.toDouble() / snapHz).roundToLong() * snapHz
            onTune?.invoke(f.coerceIn(cfg.lowFreq, cfg.highFreq))
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()

    companion object {
        private const val ROWS = 400

        private fun heat(t: Float): Int {
            // black -> deep blue -> cyan -> yellow -> red -> white
            val stops = arrayOf(
                0.00f to intArrayOf(0, 0, 8),
                0.22f to intArrayOf(10, 20, 120),
                0.42f to intArrayOf(0, 170, 220),
                0.62f to intArrayOf(240, 230, 60),
                0.82f to intArrayOf(240, 70, 30),
                1.00f to intArrayOf(255, 245, 235),
            )
            for (i in 1 until stops.size) {
                if (t <= stops[i].first) {
                    val (t0, c0) = stops[i - 1]
                    val (t1, c1) = stops[i]
                    val k = (t - t0) / (t1 - t0)
                    return Color.rgb(
                        (c0[0] + (c1[0] - c0[0]) * k).toInt(),
                        (c0[1] + (c1[1] - c0[1]) * k).toInt(),
                        (c0[2] + (c1[2] - c0[2]) * k).toInt(),
                    )
                }
            }
            return Color.WHITE
        }

        /** Rounds [raw] up to 1, 2 or 5 times a power of ten. */
        fun niceStep(raw: Double): Double {
            if (raw <= 0) return 1.0
            val p = 10.0.pow(kotlin.math.floor(kotlin.math.log10(raw)))
            val m = raw / p
            val n = when {
                m <= 1 -> 1.0
                m <= 2 -> 2.0
                m <= 5 -> 5.0
                else -> 10.0
            }
            return n * p
        }

        fun formatTick(hz: Double, step: Double): String {
            return when {
                abs(hz) >= 1e6 -> {
                    val dec = when {
                        step >= 1e6 -> 0
                        step >= 1e5 -> 1
                        step >= 1e4 -> 2
                        else -> 3
                    }
                    String.format("%.${dec}f", hz / 1e6)
                }
                abs(hz) >= 1e3 -> String.format("%.${if (step >= 1e3) 0 else 1}fk", hz / 1e3)
                else -> hz.toLong().toString()
            }
        }
    }
}
