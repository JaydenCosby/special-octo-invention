package com.example.owrx

import android.app.Application
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.owrx.audio.AudioOut
import com.example.owrx.core.Bookmark
import com.example.owrx.core.ClientListener
import com.example.owrx.core.ConnState
import com.example.owrx.core.Mode
import com.example.owrx.core.Modes
import com.example.owrx.core.OwrxClient
import com.example.owrx.core.Profile
import com.example.owrx.core.Receiver
import com.example.owrx.core.ServerConfig
import com.example.owrx.data.Store
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class RadioViewModel(app: Application) : AndroidViewModel(app), ClientListener {

    private val store = Store(app)
    private val audio = AudioOut()
    private val client = OwrxClient(this)
    private val main = Handler(Looper.getMainLooper())

    // ---- directory ----------------------------------------------------------------------
    var directory by mutableStateOf<List<Receiver>>(emptyList()); private set
    var directoryLoading by mutableStateOf(false); private set
    var directoryError by mutableStateOf<String?>(null); private set
    var favourites by mutableStateOf<Set<String>>(emptySet()); private set
    var custom by mutableStateOf<List<Receiver>>(emptyList()); private set

    // ---- connection ---------------------------------------------------------------------
    var current by mutableStateOf<Receiver?>(null); private set
    var conn by mutableStateOf(ConnState.IDLE); private set
    var connMessage by mutableStateOf<String?>(null); private set
    var cfg by mutableStateOf(ServerConfig()); private set
    var receiverName by mutableStateOf<String?>(null); private set
    var clients by mutableStateOf(0); private set

    // ---- tuning -------------------------------------------------------------------------
    var freq by mutableStateOf(0L); private set
    var mode by mutableStateOf(Modes.defaults[0]); private set
    var modes by mutableStateOf(Modes.defaults); private set
    var squelch by mutableStateOf(-150); private set
    var volume by mutableStateOf(0.8f); private set
    var muted by mutableStateOf(false); private set
    var stepHz by mutableStateOf(1000); private set
    var smeter by mutableStateOf(-130f); private set
    val profiles = mutableStateListOf<Profile>()
    var profileKey by mutableStateOf<String?>(null); private set
    val bookmarks = mutableStateListOf<Bookmark>()

    /** Set by the waterfall view; receives each FFT row on the main thread. */
    var fftSink: ((FloatArray) -> Unit)? = null

    private var firstConfigDone = false

    init {
        favourites = store.favourites()
        custom = store.custom()
        volume = store.volume()
        audio.volume = volume
        val cached = store.loadCache()
        if (cached.isNotEmpty()) directory = cached
        if (cached.isEmpty() || store.cacheAgeMs() > 6 * 3600_000L) refreshDirectory()
    }

    // ---- directory actions --------------------------------------------------------------

    fun refreshDirectory() {
        if (directoryLoading) return
        directoryLoading = true
        directoryError = null
        viewModelScope.launch {
            try {
                val list = withContext(Dispatchers.IO) { store.fetchDirectory() }
                directory = list
            } catch (e: Exception) {
                directoryError = "Could not load ReceiverBook (${e.message ?: "network error"})"
            } finally {
                directoryLoading = false
            }
        }
    }

    fun toggleFavourite(r: Receiver) {
        favourites = if (r.key in favourites) favourites - r.key else favourites + r.key
        store.setFavourites(favourites)
    }

    fun addCustom(name: String, address: String) {
        val r = Receiver(name = name.ifBlank { address.trim() }, url = address.trim(), custom = true)
        if (custom.any { it.key == r.key }) return
        custom = custom + r
        store.setCustom(custom)
    }

    fun removeCustom(r: Receiver) {
        custom = custom.filterNot { it.key == r.key }
        store.setCustom(custom)
    }

    // ---- connection ---------------------------------------------------------------------

    fun connect(r: Receiver) {
        current = r
        store.setLastReceiver(r.url)
        firstConfigDone = false
        receiverName = null
        profiles.clear(); bookmarks.clear()
        profileKey = null
        modes = Modes.defaults
        cfg = ServerConfig()
        audio.clear()
        audio.start()
        client.connect(r.url)
        startService()
    }

    fun disconnect() {
        client.disconnect()
        audio.stop()
        conn = ConnState.IDLE
        current = null
        stopService()
    }

    fun reconnect() {
        current?.let { connect(it) }
    }

    private fun startService() {
        val ctx = getApplication<Application>()
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, PlaybackService::class.java)
                .putExtra("title", current?.name ?: "OpenWebRX"))
        } catch (_: Exception) { /* background start restrictions: playback still works in foreground */ }
    }

    private fun stopService() {
        val ctx = getApplication<Application>()
        ctx.stopService(Intent(ctx, PlaybackService::class.java))
    }

    override fun onCleared() {
        client.disconnect()
        audio.stop()
        stopService()
    }

    // ---- tuning actions -----------------------------------------------------------------

    fun tune(hz: Long) {
        if (!cfg.ready) return
        freq = hz.coerceIn(cfg.lowFreq + 1, cfg.highFreq - 1)
        pushDsp()
    }

    fun nudge(deltaHz: Long) = tune(freq + deltaHz)

    fun setStep(hz: Int) { stepHz = hz }

    fun selectMode(m: Mode) {
        mode = m
        stepHz = m.defaultStep
        pushDsp()
    }

    fun setBandwidth(width: Int) {
        mode = mode.withWidth(width)
        pushDsp()
    }

    fun setSquelch(v: Int) { squelch = v; pushDsp() }

    fun setVolume(v: Float) {
        volume = v
        audio.volume = v
        store.setVolume(v)
    }

    fun toggleMute() { muted = !muted; audio.muted = muted }

    fun jump(freqHz: Long, modeId: String?) {
        modeId?.let { id -> modes.firstOrNull { it.id == id }?.let { mode = it; stepHz = it.defaultStep } }
        tune(freqHz)
    }

    fun selectProfile(key: String) {
        client.selectProfile(key)
    }

    private fun pushDsp() {
        if (!cfg.ready) return
        client.setDsp(
            mapOf(
                "low_cut" to mode.low,
                "high_cut" to mode.high,
                "offset_freq" to (freq - cfg.centerFreq),
                "mod" to mode.id,
                "squelch_level" to squelch,
            )
        )
    }

    // ---- ClientListener (called on network thread) --------------------------------------

    override fun onState(state: ConnState, message: String?) {
        main.post {
            conn = state
            connMessage = message
            if (state == ConnState.ERROR || state == ConnState.BUSY) audio.clear()
        }
    }

    override fun onConfig(cfg: ServerConfig) {
        main.post {
            val centerChanged = this.cfg.centerFreq != cfg.centerFreq || this.cfg.sampRate != cfg.sampRate
            this.cfg = cfg
            profileKey = cfg.profileKey ?: profileKey
            if (!firstConfigDone || centerChanged) {
                firstConfigDone = true
                freq = cfg.centerFreq + cfg.startOffset
                cfg.startMod?.let { id ->
                    modes.firstOrNull { it.id == id }?.let { mode = it }
                }
                stepHz = mode.defaultStep
                squelch = cfg.squelch.coerceIn(-150, 0)
            }
            pushDsp()
        }
    }

    override fun onFft(db: FloatArray) {
        main.post { fftSink?.invoke(db) }
    }

    override fun onAudio(pcm: ShortArray, hd: Boolean) {
        audio.push(pcm, hd)
    }

    override fun onSmeter(db: Float) {
        main.post { smeter = db }
    }

    override fun onProfiles(list: List<Profile>, currentKey: String?) {
        main.post {
            profiles.clear(); profiles.addAll(list)
            if (currentKey != null) profileKey = currentKey
        }
    }

    override fun onModes(modes: List<Mode>) {
        main.post {
            this.modes = modes
            // keep selection consistent with what the server actually offers
            modes.firstOrNull { it.id == mode.id }?.let { mode = it }
        }
    }

    override fun onBookmarks(list: List<Bookmark>) {
        main.post {
            bookmarks.clear()
            bookmarks.addAll(list.sortedBy { it.frequency })
        }
    }

    override fun onDetails(name: String?, location: String?) {
        main.post { receiverName = name }
    }

    override fun onClients(count: Int) {
        main.post { clients = count }
    }
}
