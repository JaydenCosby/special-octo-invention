package com.example.owrx.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material.icons.filled.FitScreen
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.gestures.detectTapGestures
import com.example.owrx.RadioViewModel
import com.example.owrx.core.Bands
import com.example.owrx.core.ConnState
import com.example.owrx.core.Receiver
import kotlin.math.pow
import kotlin.math.roundToInt

// ======================================================================================
// Receiver browser
// ======================================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReceiverListScreen(vm: RadioViewModel, onOpen: (Receiver) -> Unit) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(0) } // 0 all, 1 favourites, 2 mine
    var showAdd by remember { mutableStateOf(false) }

    val all = remember(vm.directory, vm.custom) {
        (vm.custom + vm.directory).distinctBy { it.key }
    }
    val shown = remember(all, query, filter, vm.favourites) {
        all.filter { r ->
            (filter != 1 || r.key in vm.favourites) &&
                (filter != 2 || r.custom) &&
                (query.isBlank() ||
                    r.name.contains(query, true) ||
                    (r.place?.contains(query, true) ?: false) ||
                    r.host.contains(query, true))
        }.sortedWith(compareByDescending<Receiver> { it.key in vm.favourites }.thenBy { it.name.lowercase() })
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("OpenWebRX Receivers") },
                actions = {
                    if (vm.directoryLoading) {
                        CircularProgressIndicator(Modifier.size(22.dp).padding(end = 2.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(12.dp))
                    } else {
                        IconButton(onClick = { vm.refreshDirectory() }) {
                            Icon(Icons.Default.Refresh, "Refresh from ReceiverBook")
                        }
                    }
                    IconButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, "Add receiver") }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                placeholder = { Text("Search name, place or host") },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
            )
            Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("All ${all.size}", "Favourites", "Mine").forEachIndexed { i, label ->
                    FilterChip(selected = filter == i, onClick = { filter = i }, label = { Text(label) })
                }
            }
            vm.directoryError?.let {
                Text(
                    it + if (all.isEmpty()) "\nYou can still add a receiver address with the + button." else "",
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                    fontSize = 13.sp
                )
            }
            if (shown.isEmpty() && !vm.directoryLoading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        if (all.isEmpty()) "No receivers yet" else "Nothing matches",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            LazyColumn(Modifier.fillMaxSize()) {
                items(shown, key = { it.key }) { r ->
                    ReceiverRow(
                        r = r,
                        fav = r.key in vm.favourites,
                        onClick = { onOpen(r) },
                        onFav = { vm.toggleFavourite(r) },
                        onDelete = if (r.custom) ({ vm.removeCustom(r) }) else null
                    )
                }
            }
        }
    }

    if (showAdd) AddReceiverDialog(onDismiss = { showAdd = false }) { name, addr ->
        vm.addCustom(name, addr); showAdd = false
    }
}

@Composable
private fun ReceiverRow(r: Receiver, fav: Boolean, onClick: () -> Unit, onFav: () -> Unit, onDelete: (() -> Unit)?) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(r.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val sub = listOfNotNull(r.place, r.host).joinToString("  ·  ")
            Text(sub, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (onDelete != null) {
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Remove") }
        }
        IconButton(onClick = onFav) {
            Icon(
                if (fav) Icons.Default.Star else Icons.Default.StarBorder, "Favourite",
                tint = if (fav) Color(0xFFFFC83D) else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun AddReceiverDialog(onDismiss: () -> Unit, onAdd: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var addr by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add receiver") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(addr, { addr = it }, singleLine = true, label = { Text("Address, e.g. sdr.example.org:8073") })
                OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Name (optional)") })
            }
        },
        confirmButton = { TextButton(onClick = { onAdd(name, addr) }, enabled = addr.isNotBlank()) { Text("Add") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ======================================================================================
// Tuner
// ======================================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TunerScreen(vm: RadioViewModel, onBack: () -> Unit) {
    var showBookmarks by remember { mutableStateOf(false) }
    var showFreqEntry by remember { mutableStateOf(false) }
    var profileMenu by remember { mutableStateOf(false) }
    val landscape = LocalConfiguration.current.screenWidthDp > LocalConfiguration.current.screenHeightDp

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(vm.receiverName ?: vm.current?.name ?: "Receiver", maxLines = 1,
                            overflow = TextOverflow.Ellipsis, fontSize = 17.sp)
                        Text(statusText(vm), fontSize = 11.sp, color = statusColor(vm))
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                },
                actions = {
                    if (vm.profiles.size > 1) {
                        Box {
                            TextButton(onClick = { profileMenu = true }) {
                                Text(vm.profiles.firstOrNull { it.id == vm.profileKey }?.name ?: "Band", maxLines = 1)
                            }
                            DropdownMenu(expanded = profileMenu, onDismissRequest = { profileMenu = false }) {
                                vm.profiles.forEach { p ->
                                    DropdownMenuItem(text = { Text(p.name) }, onClick = {
                                        profileMenu = false; vm.selectProfile(p.id)
                                    })
                                }
                            }
                        }
                    }
                    IconButton(onClick = { showBookmarks = true }, enabled = vm.bookmarks.isNotEmpty()) {
                        Icon(Icons.Default.Bookmarks, "Bookmarks")
                    }
                }
            )
        }
    ) { pad ->
        val content: @Composable () -> Unit = {
            if (landscape) {
                Row(Modifier.padding(pad).fillMaxSize()) {
                    Box(Modifier.weight(1.1f).fillMaxSize()) { WaterfallPane(vm) }
                    Column(Modifier.weight(1f).fillMaxSize().verticalScroll(rememberScrollState())) { Controls(vm) { showFreqEntry = true } }
                }
            } else {
                Column(Modifier.padding(pad).fillMaxSize()) {
                    Box(Modifier.weight(1f).fillMaxWidth()) { WaterfallPane(vm) }
                    Column(Modifier.fillMaxWidth().heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                        Controls(vm) { showFreqEntry = true }
                    }
                }
            }
        }
        content()
    }

    if (showBookmarks) BookmarkDialog(vm) { showBookmarks = false }
    if (showFreqEntry) FrequencyDialog(vm.freq) { hz -> hz?.let { vm.tune(it) }; showFreqEntry = false }
}

private fun statusText(vm: RadioViewModel): String = when (vm.conn) {
    ConnState.IDLE -> vm.connMessage ?: "Not connected"
    ConnState.CONNECTING -> "Connecting…"
    ConnState.LIVE -> "Live" + if (vm.clients > 0) " · ${vm.clients} listening" else ""
    ConnState.BUSY -> vm.connMessage ?: "Server busy"
    ConnState.ERROR -> vm.connMessage ?: "Connection failed"
}

@Composable
private fun statusColor(vm: RadioViewModel): Color = when (vm.conn) {
    ConnState.LIVE -> Color(0xFF58D68D)
    ConnState.CONNECTING -> Color(0xFFF7DC6F)
    ConnState.IDLE -> MaterialTheme.colorScheme.onSurfaceVariant
    else -> MaterialTheme.colorScheme.error
}

@Composable
private fun WaterfallPane(vm: RadioViewModel) {
    Box(Modifier.fillMaxSize().background(Color(0xFF080C14))) {
        var view by remember { mutableStateOf<WaterfallView?>(null) }

        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                WaterfallView(ctx).also { w ->
                    w.onTune = { hz -> vm.tune(hz) }
                    vm.fftSink = { db -> w.addRow(db) }
                    view = w
                }
            },
            update = { w ->
                w.setConfig(vm.cfg)
                w.tunedHz = vm.freq
                w.lowCut = vm.mode.low
                w.highCut = vm.mode.high
                w.snapHz = 0
            }
        )

        // follow the tuned frequency when it is changed by buttons/bookmarks
        androidx.compose.runtime.LaunchedEffect(vm.freq) { view?.followTuned() }

        androidx.compose.runtime.DisposableEffect(Unit) {
            onDispose { vm.fftSink = null }
        }

        Column(Modifier.align(Alignment.TopEnd).padding(top = 4.dp, end = 4.dp)) {
            SmallRoundButton({ view?.zoomBy(1.6) }) { Icon(Icons.Default.ZoomIn, "Zoom in", tint = Color.White) }
            Spacer(Modifier.height(4.dp))
            SmallRoundButton({ view?.zoomBy(1 / 1.6) }) { Icon(Icons.Default.ZoomOut, "Zoom out", tint = Color.White) }
            Spacer(Modifier.height(4.dp))
            SmallRoundButton({ view?.showAll() }) { Icon(Icons.Default.FitScreen, "Show whole band", tint = Color.White) }
        }

        if (vm.conn == ConnState.CONNECTING || (vm.conn == ConnState.LIVE && !vm.cfg.ready)) {
            CircularProgressIndicator(Modifier.align(Alignment.Center))
        }
        if (vm.conn == ConnState.ERROR || vm.conn == ConnState.BUSY) {
            Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(statusText(vm), color = Color.White)
                Spacer(Modifier.height(8.dp))
                Button(onClick = { vm.reconnect() }) { Text("Retry") }
            }
        }
    }
}

@Composable
private fun SmallRoundButton(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier.size(36.dp).clip(RoundedCornerShape(18.dp)).background(Color(0x99000000)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
private fun Controls(vm: RadioViewModel, onEditFreq: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {

        // --- dial + s-meter ---
        Row(verticalAlignment = Alignment.CenterVertically) {
            FrequencyDial(vm.freq, Modifier.weight(1f), onSetFreq = { vm.tune(it) })
            IconButton(onClick = onEditFreq) { Icon(Icons.Default.Edit, "Enter frequency") }
        }
        SMeter(vm.smeter)

        // --- step tuning ---
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.nudge(-vm.stepHz.toLong()) }) { Text("◀") }
            OutlinedButton(onClick = { vm.nudge(vm.stepHz.toLong()) }) { Text("▶") }
            Spacer(Modifier.width(4.dp))
            Text("Step", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                STEPS.forEach { s ->
                    FilterChip(selected = vm.stepHz == s, onClick = { vm.setStep(s) }, label = { Text(stepLabel(s)) })
                }
            }
        }

        // --- modes ---
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            vm.modes.forEach { m ->
                FilterChip(selected = m.id == vm.mode.id, onClick = { vm.selectMode(m) }, label = { Text(m.label) })
            }
        }

        // --- sliders ---
        val m = vm.mode
        LabeledSlider("Bandwidth", widthLabel(m.width), m.width.toFloat(), m.minWidth.toFloat()..m.maxWidth.toFloat()) {
            vm.setBandwidth(it.roundToInt())
        }
        LabeledSlider("Squelch", if (vm.squelch <= -150) "off" else "${vm.squelch} dB",
            vm.squelch.toFloat().coerceIn(-150f, 0f), -150f..0f) { vm.updateSquelch(it.roundToInt()) }

        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.toggleMute() }) {
                Icon(if (vm.muted) Icons.Default.VolumeOff else Icons.Default.VolumeUp, "Mute")
            }
            Slider(vm.volume, { vm.updateVolume(it) }, Modifier.weight(1f))
        }

        // --- band shortcuts ---
        val bands = Bands.inRange(vm.cfg)
        if (bands.isNotEmpty()) {
            Text("Jump to", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                bands.forEach { b ->
                    FilterChip(selected = false, onClick = { vm.jump(b.freq, b.mode) }, label = { Text(b.label) })
                }
            }
        }
    }
}

@Composable
private fun LabeledSlider(label: String, valueText: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column {
        Row {
            Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.weight(1f))
            Text(valueText, fontSize = 12.sp)
        }
        Slider(value.coerceIn(range.start, range.endInclusive), onChange, valueRange = range)
    }
}

private val STEPS = listOf(100, 500, 1000, 5000, 9000, 10000, 12500, 25000, 100000)

private fun stepLabel(hz: Int) = if (hz >= 1000) {
    val k = hz / 1000.0
    (if (k == k.toInt().toDouble()) k.toInt().toString() else k.toString()) + "k"
} else "$hz"

private fun widthLabel(hz: Int) = if (hz >= 1000) String.format("%.1f kHz", hz / 1000.0) else "$hz Hz"

// ======================================================================================
// Frequency dial: tap the upper half of a digit to raise it, the lower half to lower it
// ======================================================================================

@Composable
private fun FrequencyDial(freq: Long, modifier: Modifier, onSetFreq: (Long) -> Unit) {
    val text = remember(freq) { String.format("%010d", freq.coerceAtLeast(0)) } // up to 9.99 GHz
    val digits = text.map { it - '0' }
    Row(
        modifier.clip(RoundedCornerShape(10.dp)).background(Color(0xFF0B1220))
            .border(BorderStroke(1.dp, Color(0xFF2A3A55)), RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        var leading = true
        digits.forEachIndexed { i, d ->
            val place = 10.0.pow(9 - i).toLong()
            // leading zeros are dimmed, except the ones at/after the MHz group
            if (leading && d != 0) leading = false
            val dim = leading && i < 6
            if (i == 4 || i == 7) Text(".", fontSize = 30.sp, color = Color(0xFF7F93B5), fontFamily = FontFamily.Monospace)
            Box(
                Modifier.width(22.dp).height(52.dp).pointerInput(freq) {
                    detectTapGestures { offset ->
                        val up = offset.y < size.height / 2f
                        onSetFreq(freq + if (up) place else -place)
                    }
                },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    d.toString(), fontSize = 32.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Medium,
                    color = if (dim) Color(0xFF3A4A66) else Color(0xFF8CF5A8)
                )
            }
        }
        Spacer(Modifier.width(6.dp))
        Text("Hz", fontSize = 12.sp, color = Color(0xFF7F93B5))
    }
}

@Composable
private fun SMeter(db: Float) {
    // S9 = -73 dBm on HF; each S unit is 6 dB. The server reports dB relative to full scale,
    // so the bar is a relative indicator, not a calibrated S-reading.
    val frac = ((db + 120f) / 90f).coerceIn(0f, 1f)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.weight(1f).height(10.dp).clip(RoundedCornerShape(5.dp)).background(Color(0xFF1B2538))) {
            Box(
                Modifier.fillMaxHeight().fillMaxWidth(frac)
                    .background(if (frac > 0.75f) Color(0xFFE74C3C) else Color(0xFF58D68D))
            )
        }
        Spacer(Modifier.width(8.dp))
        Text(String.format("%.0f dB", db), fontSize = 12.sp, fontFamily = FontFamily.Monospace)
    }
}

// ======================================================================================
// Dialogs
// ======================================================================================

@Composable
private fun BookmarkDialog(vm: RadioViewModel, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Bookmarks") },
        text = {
            LazyColumn(Modifier.heightIn(max = 400.dp)) {
                items(vm.bookmarks) { b ->
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.jump(b.frequency, b.modulation); onDismiss() }
                            .padding(vertical = 10.dp)
                    ) {
                        Text(b.name.ifBlank { "—" }, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(formatMHz(b.frequency) + (b.modulation?.let { "  ${it.uppercase()}" } ?: ""),
                            fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
private fun FrequencyDialog(current: Long, onResult: (Long?) -> Unit) {
    var text by remember { mutableStateOf(String.format("%.4f", current / 1e6).trimEnd('0').trimEnd('.')) }
    val parsed = parseFrequency(text)
    AlertDialog(
        onDismissRequest = { onResult(null) },
        title = { Text("Go to frequency") },
        text = {
            OutlinedTextField(
                text, { text = it }, singleLine = true,
                label = { Text("MHz (or add k for kHz)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            )
        },
        confirmButton = { TextButton(onClick = { onResult(parsed) }, enabled = parsed != null) { Text("Tune") } },
        dismissButton = { TextButton(onClick = { onResult(null) }) { Text("Cancel") } }
    )
}

/** "14.2" -> 14.2 MHz, "7100k" -> 7.1 MHz, "145500000" -> taken as Hz when above 100 000. */
fun parseFrequency(s: String): Long? {
    val t = s.trim().lowercase().replace(",", ".")
    if (t.isEmpty()) return null
    return try {
        when {
            t.endsWith("k") -> (t.dropLast(1).toDouble() * 1e3).toLong()
            t.endsWith("m") -> (t.dropLast(1).toDouble() * 1e6).toLong()
            else -> {
                val v = t.toDouble()
                if (v >= 100_000) v.toLong() else (v * 1e6).toLong()
            }
        }.takeIf { it > 0 }
    } catch (_: NumberFormatException) {
        null
    }
}

fun formatMHz(hz: Long): String = String.format("%.4f MHz", hz / 1e6)
