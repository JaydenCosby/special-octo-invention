package com.example.owrx.core

/** One public OpenWebRX receiver. */
data class Receiver(
    val name: String,
    val url: String,
    val place: String? = null,
    val lat: Double? = null,
    val lon: Double? = null,
    val version: String? = null,
    val custom: Boolean = false,
) {
    val key: String get() = Protocol.normalizeUrl(url)

    val host: String get() = url.substringAfter("://").substringBefore('/')

    fun toMap(): Map<String, Any?> = mapOf(
        "name" to name, "url" to url, "place" to place, "lat" to lat, "lon" to lon,
        "version" to version, "custom" to custom
    )

    companion object {
        fun fromMap(m: Map<String, Any?>): Receiver? {
            val url = m["url"].jStr() ?: return null
            return Receiver(
                name = m["name"].jStr() ?: url,
                url = url,
                place = m["place"].jStr(),
                lat = m["lat"].jNum(),
                lon = m["lon"].jNum(),
                version = m["version"].jStr(),
                custom = m["custom"] as? Boolean ?: false,
            )
        }
    }
}

/**
 * Reads the receiver directory published by receiverbook.de.
 *
 * The site embeds its station list as JSON in the page (a "receivers" array of stations,
 * each with a label, a GeoJSON-style location and a list of receivers with a type and URL).
 * Parsing is deliberately tolerant: it accepts a raw JSON document, a JSON array embedded in
 * HTML, and either nested (station -> receivers) or flat entries.
 */
object ReceiverBook {
    /** Pages tried in order until one yields receivers. */
    val SOURCES = listOf(
        "https://www.receiverbook.de/map",
        "https://www.receiverbook.de/",
    )

    fun parse(text: String): List<Receiver> {
        val roots = ArrayList<Any?>()

        // 1. whole response is JSON
        val trimmed = text.trimStart()
        if (trimmed.startsWith("[") || trimmed.startsWith("{")) {
            try { roots.add(Json.parse(text)) } catch (_: Exception) { /* fall through */ }
        }

        // 2. JSON assigned to a variable inside a <script>: receivers = [ ... ]
        if (roots.isEmpty()) {
            val rx = Regex("""(?:var|let|const)?\s*receivers\s*=\s*([\[{])""")
            for (m in rx.findAll(text)) {
                val start = m.groups[1]!!.range.first
                try {
                    roots.add(Json.parsePrefix(text, start).first)
                    break
                } catch (_: Exception) { /* try next candidate */ }
            }
        }

        val out = LinkedHashMap<String, Receiver>()
        for (r in roots) collect(r, null, null, null, out)
        return out.values.toList()
    }

    private fun collect(
        node: Any?,
        stationLabel: String?,
        lat: Double?,
        lon: Double?,
        out: MutableMap<String, Receiver>,
    ) {
        when (node) {
            is List<*> -> node.forEach { collect(it, stationLabel, lat, lon, out) }
            is Map<*, *> -> {
                val m = node.jMap() ?: return
                val label = m["label"].jStr() ?: m["name"].jStr()
                val coords = m["location"].jMap()?.get("coordinates").jList()
                val newLon = coords?.getOrNull(0).jNum() ?: m["lon"].jNum() ?: lon
                val newLat = coords?.getOrNull(1).jNum() ?: m["lat"].jNum() ?: lat

                val type = m["type"].jStr()?.lowercase()
                val url = m["url"].jStr()
                if (url != null && type != null && type.contains("openwebrx")) {
                    val r = Receiver(
                        name = label ?: stationLabel ?: url.substringAfter("://").substringBefore('/'),
                        url = url,
                        place = if (label != null) stationLabel?.takeIf { it != label } else null,
                        lat = newLat,
                        lon = newLon,
                        version = m["version"].jStr(),
                    )
                    out.putIfAbsent(r.key, r)
                }

                val nextStation = if (m["receivers"] != null) (label ?: stationLabel) else stationLabel
                for ((k, v) in m) {
                    if (v is List<*> || v is Map<*, *>) {
                        if (k == "location") continue
                        collect(v, nextStation, newLat, newLon, out)
                    }
                }
            }
            else -> {}
        }
    }
}
