package com.example.owrx.data

import android.content.Context
import com.example.owrx.core.Json
import com.example.owrx.core.Receiver
import com.example.owrx.core.ReceiverBook
import com.example.owrx.core.jList
import com.example.owrx.core.jMap
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

/** Persistent app data: receiver directory cache, favourites, custom receivers, last tuning. */
class Store(private val ctx: Context) {

    private val prefs = ctx.getSharedPreferences("owrx", Context.MODE_PRIVATE)
    private val cacheFile get() = File(ctx.filesDir, "receiverbook.json")

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    // ---- receiver directory -------------------------------------------------------------

    /** Downloads the directory from ReceiverBook. Throws when no source gives any receiver. */
    fun fetchDirectory(): List<Receiver> {
        var lastError: Exception? = null
        for (src in ReceiverBook.SOURCES) {
            try {
                val req = Request.Builder().url(src)
                    .header("User-Agent", "OpenWebRX-Android/1.0")
                    .header("Accept", "application/json,text/html")
                    .build()
                http.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) throw IllegalStateException("HTTP ${resp.code}")
                    val body = resp.body?.string() ?: throw IllegalStateException("Empty response")
                    val list = ReceiverBook.parse(body)
                    if (list.isNotEmpty()) {
                        saveCache(list)
                        return list
                    }
                }
            } catch (e: Exception) {
                lastError = e
            }
        }
        throw lastError ?: IllegalStateException("No receivers found")
    }

    fun loadCache(): List<Receiver> = try {
        if (!cacheFile.exists()) emptyList()
        else Json.parse(cacheFile.readText()).jList().orEmpty()
            .mapNotNull { it.jMap()?.let(Receiver::fromMap) }
    } catch (_: Exception) {
        emptyList()
    }

    fun cacheAgeMs(): Long = if (cacheFile.exists()) System.currentTimeMillis() - cacheFile.lastModified() else Long.MAX_VALUE

    private fun saveCache(list: List<Receiver>) {
        try { cacheFile.writeText(Json.stringify(list.map { it.toMap() })) } catch (_: Exception) {}
    }

    // ---- favourites / custom ------------------------------------------------------------

    fun favourites(): Set<String> = prefs.getStringSet("fav", emptySet()) ?: emptySet()

    fun setFavourites(s: Set<String>) = prefs.edit().putStringSet("fav", s).apply()

    fun custom(): List<Receiver> = try {
        Json.parse(prefs.getString("custom", "[]") ?: "[]").jList().orEmpty()
            .mapNotNull { it.jMap()?.let(Receiver::fromMap) }
    } catch (_: Exception) {
        emptyList()
    }

    fun setCustom(list: List<Receiver>) =
        prefs.edit().putString("custom", Json.stringify(list.map { it.toMap() })).apply()

    // ---- last session -------------------------------------------------------------------

    fun lastReceiver(): String? = prefs.getString("last_url", null)
    fun setLastReceiver(url: String) = prefs.edit().putString("last_url", url).apply()

    fun volume(): Float = prefs.getFloat("volume", 0.8f)
    fun setVolume(v: Float) = prefs.edit().putFloat("volume", v).apply()
}
