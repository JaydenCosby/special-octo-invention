package com.example.owrx.core

import kotlin.math.abs
import kotlin.math.max

/** An analog demodulation mode together with its default passband (Hz, relative to the carrier). */
data class Mode(
    val id: String,
    val label: String,
    val low: Int,
    val high: Int,
) {
    val width: Int get() = high - low

    /** Smallest/largest passband the width slider offers for this mode. */
    val minWidth: Int get() = when (id) {
        "cw" -> 50
        "lsb", "usb" -> 500
        "wfm" -> 40000
        else -> 1000
    }
    val maxWidth: Int get() = when (id) {
        "cw" -> 1000
        "lsb", "usb" -> 6000
        "wfm" -> 220000
        "nfm" -> 25000
        else -> max(width * 2, 16000)
    }

    /** Returns this mode with the passband resized to [w] Hz, keeping the sideband/carrier anchoring. */
    fun withWidth(w: Int): Mode {
        val width = w.coerceIn(minWidth, maxWidth)
        return when (id) {
            "usb" -> copy(low = low.coerceAtLeast(0), high = low.coerceAtLeast(0) + width)
            "lsb" -> copy(low = high.coerceAtMost(0) - width, high = high.coerceAtMost(0))
            "cw" -> {
                val c = (low + high) / 2
                copy(low = c - width / 2, high = c + width / 2)
            }
            else -> copy(low = -width / 2, high = width / 2)
        }
    }

    /** Typical channel spacing, used as the initial tuning step. */
    val defaultStep: Int get() = when (id) {
        "am" -> 5000
        "nfm" -> 12500
        "wfm" -> 100000
        "cw" -> 100
        else -> 1000
    }
}

object Modes {
    val defaults: List<Mode> = listOf(
        Mode("am", "AM", -4000, 4000),
        Mode("nfm", "NFM", -4000, 4000),
        Mode("wfm", "WFM", -80000, 80000),
        Mode("lsb", "LSB", -3000, -300),
        Mode("usb", "USB", 300, 3000),
        Mode("cw", "CW", 700, 900),
    )

    /**
     * Builds the mode list out of the server's "modes" message. Only analog modes are kept
     * because this client plays audio only (no digital decoders).
     */
    fun fromServer(value: Any?): List<Mode> {
        val list = value.jList() ?: return emptyList()
        val out = ArrayList<Mode>()
        for (item in list) {
            val m = item.jMap() ?: continue
            val type = m["type"].jStr()
            if (type != null && type != "analog") continue
            val id = m["modulation"].jStr() ?: continue
            val bp = m["bandpass"].jMap()
            val low = bp?.get("low_cut").jNum()?.toInt()
            val high = bp?.get("high_cut").jNum()?.toInt()
            val fallback = defaults.firstOrNull { it.id == id }
            val label = m["name"].jStr() ?: fallback?.label ?: id.uppercase()
            val l = low ?: fallback?.low ?: continue
            val h = high ?: fallback?.high ?: continue
            if (abs(h - l) < 10) continue
            out.add(Mode(id, label, l, h))
        }
        return out
    }
}

/** Quick-jump presets (only the ones inside the receiver's current coverage are offered). */
data class BandPreset(val label: String, val freq: Long, val mode: String)

object Bands {
    val all: List<BandPreset> = listOf(
        BandPreset("MW", 1_000_000, "am"),
        BandPreset("160m", 1_840_000, "lsb"),
        BandPreset("80m", 3_700_000, "lsb"),
        BandPreset("49m", 6_000_000, "am"),
        BandPreset("40m", 7_100_000, "lsb"),
        BandPreset("31m", 9_600_000, "am"),
        BandPreset("30m", 10_130_000, "usb"),
        BandPreset("25m", 11_800_000, "am"),
        BandPreset("20m", 14_200_000, "usb"),
        BandPreset("19m", 15_300_000, "am"),
        BandPreset("17m", 18_130_000, "usb"),
        BandPreset("15m", 21_300_000, "usb"),
        BandPreset("CB", 27_185_000, "am"),
        BandPreset("10m", 28_400_000, "usb"),
        BandPreset("6m", 50_150_000, "usb"),
        BandPreset("FM", 100_000_000, "wfm"),
        BandPreset("Air", 121_500_000, "am"),
        BandPreset("2m", 145_500_000, "nfm"),
        BandPreset("Marine", 156_800_000, "nfm"),
        BandPreset("NOAA", 162_550_000, "nfm"),
        BandPreset("70cm", 433_500_000, "nfm"),
        BandPreset("PMR", 446_100_000, "nfm"),
    )

    fun inRange(cfg: ServerConfig): List<BandPreset> =
        all.filter { it.freq > cfg.lowFreq + 2000 && it.freq < cfg.highFreq - 2000 }
}
