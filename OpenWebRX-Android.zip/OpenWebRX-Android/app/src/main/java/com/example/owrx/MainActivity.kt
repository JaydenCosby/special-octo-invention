package com.example.owrx

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import com.example.owrx.ui.ReceiverListScreen
import com.example.owrx.ui.TunerScreen

class MainActivity : ComponentActivity() {

    private val vm: RadioViewModel by viewModels()

    private val askNotifications =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* optional */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)

        setContent {
            val dark = isSystemInDarkTheme()
            MaterialTheme(
                colorScheme = if (dark) darkColorScheme(primary = Color(0xFF6CB4FF), background = Color(0xFF0E131C), surface = Color(0xFF0E131C))
                else lightColorScheme(primary = Color(0xFF1A66C2))
            ) {
                Surface {
                    var onTuner by rememberSaveable { mutableStateOf(vm.current != null) }
                    if (onTuner && vm.current != null) {
                        BackHandler { vm.disconnect(); onTuner = false }
                        TunerScreen(vm) { vm.disconnect(); onTuner = false }
                    } else {
                        ReceiverListScreen(vm) { r -> vm.connect(r); onTuner = true }
                    }
                }
            }
        }
    }
}
